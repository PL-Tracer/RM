#ifndef _SERIALCONFIG_H
#define _SERIALCONFIG_H

#define GUARD_MODE    //GUARD_MODE



#endif
