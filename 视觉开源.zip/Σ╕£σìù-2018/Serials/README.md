# Communication  protocol
Communication  protocol with sentry only