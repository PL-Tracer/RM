﻿#pragma once

namespace rm
{

enum ColorChannels
{
	BLUE = 0,
	GREEN = 1,
	RED = 2
};

enum ObjectType
{
	UNKNOWN_ARMOR = 0,
	SMALL_ARMOR = 1,
	BIG_ARMOR = 2,
	MINI_RUNE = 3,
	GREAT_RUNE = 4
};



}